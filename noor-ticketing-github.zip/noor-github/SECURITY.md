# Security Policy — Noor Ticketing System

## Supported Versions

| Version | Supported |
|---------|-----------|
| 1.x     | ✅ Active  |

## Important Security Notes

### Before Going Live — MANDATORY

1. **Change all default passwords** in `NoorTicketing.html`
   - Find `DEMO_ACCOUNTS` array and update every `password` field
   - Use passwords with minimum 12 characters, mixed case, numbers and symbols

2. **Never commit `.env` files** to this repository
   - The `.gitignore` already excludes `.env` files
   - Store production secrets in your server's environment variables only

3. **Enable HTTPS** on your production server
   - Use Let's Encrypt (free) — see the deployment guide

4. **Restrict repository access**
   - Set repository to **Private** if it contains real employee or patient data
   - Only grant access to authorised IT staff

## Reporting a Security Issue

If you discover a security vulnerability in this system:

1. **Do NOT create a public GitHub Issue**
2. Contact the IT Administrator directly: admin@noor.ae
3. Include a description of the issue and steps to reproduce
4. We will respond within 48 hours

## What This System Stores

**Current version (HTML demo):**
- No persistent data storage — all data is in-memory only
- No patient health records or PHI
- Resets on page refresh

**Production version (with backend):**
- Staff names, emails, and role assignments
- IT support ticket descriptions
- Asset records (equipment, not patient equipment)
- Internal chat messages between staff

This system is NOT designed to store patient health records.
