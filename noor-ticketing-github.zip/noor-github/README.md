# ✦ Noor Ticketing System
### نظام تذاكر نور — Internal Clinic IT Support Portal

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Deploy](https://img.shields.io/badge/Deploy-GitHub%20Pages-blue)](https://pages.github.com/)
[![HTML](https://img.shields.io/badge/Built%20with-HTML%20%2B%20React-61DAFB)](https://react.dev/)

A fully self-contained internal IT support ticketing system built for Noor Clinic Group.
Covers 8 branches across the UAE — no build tools or server required to run.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔐 Role-based login | Admin, Supervisor, Agent, End-User — each sees only their screens |
| 🎫 Ticket management | Create, assign, track, comment, and close support tickets |
| 📦 Asset tracking | Full asset register with Employee ID, warranty, and branch assignment |
| 💬 Internal messaging | Direct chat between users and admin with unread badges |
| 🏥 Branch management | Add, edit, activate/deactivate clinic branches |
| 👥 User management | Full CRUD for users, roles, passwords, and branch assignment |
| 🛡️ Access control | Per-role screen permission matrix in Master Config |
| 📊 Reports | SLA compliance, resolution rates, branch performance |
| ⚙️ Settings | SMTP email + SMS gateway configuration (AES-256 encrypted) |

---

## 🚀 Quick Start

### Option A — Open Locally (No Setup)
```bash
# Simply double-click the file:
NoorTicketing.html
# Opens directly in Chrome or Edge — no server needed
```

### Option B — GitHub Pages (Free Hosting)
1. Fork this repository
2. Go to **Settings → Pages**
3. Set source to `main` branch, folder `/` (root)
4. Visit `https://YOUR-USERNAME.github.io/noor-ticketing/`

### Option C — Your Own Server
```bash
# Upload to Nginx web root
scp NoorTicketing.html root@YOUR_SERVER_IP:/var/www/html/
```
See the full [Deployment Guide](./docs/NoorTicketing-DeploymentGuide.docx) for step-by-step server setup.

---

## 🔑 Demo Login Credentials

| Role | Email | Password | Access Level |
|---|---|---|---|
| **Admin** | admin@noor.ae | Admin123 | Full access — all screens |
| **Supervisor** | fatima@noor.ae | Fatima123 | Dashboard, tickets, users, reports |
| **Agent** | omar@noor.ae | Omar123 | Tickets, assets, messages |
| **End-User** | ahmed@noor.ae | Ahmed123 | My tickets, my assets, messages only |
| **End-User** | sara@noor.ae | Sara123 | My tickets, my assets, messages only |

> ⚠️ **Change all passwords before going live.** Edit the `DEMO_ACCOUNTS` array in `NoorTicketing.html`.

---

## 📁 Repository Structure

```
noor-ticketing/
│
├── NoorTicketing.html          ← Complete application (single file)
├── LICENSE                     ← MIT License
├── README.md                   ← This file
│
├── docs/
│   └── NoorTicketing-DeploymentGuide.docx  ← Full deployment guide
│
├── backend/                    ← Node.js + PostgreSQL API (future)
│   ├── src/
│   │   ├── index.ts            ← Express app entry point
│   │   ├── config/             ← DB, Redis, encryption
│   │   ├── modules/            ← auth, tickets, assets, users, settings
│   │   └── shared/             ← middleware, errors
│   ├── migrations/
│   │   └── 001_initial_schema.sql
│   ├── package.json
│   ├── tsconfig.json
│   ├── Dockerfile
│   └── .env.example
│
├── infra/
│   ├── docker-compose.yml      ← Full stack: API + DB + Redis + Nginx
│   └── nginx/nginx.conf        ← Production Nginx config
│
└── .github/
    └── workflows/
        └── deploy.yml          ← Auto-deploy to GitHub Pages
```

---

## 🏗️ Technology Stack

### Frontend (Current)
- **React 18** — loaded via CDN (no build step)
- **Tailwind CSS** — loaded via CDN
- **Babel Standalone** — JSX compilation in-browser
- **Google Fonts** — Inter + DM Mono

### Backend (When Ready)
- **Node.js 20** + Express + TypeScript
- **PostgreSQL 16** — primary database
- **Redis 7** — sessions + job queue (BullMQ)
- **JWT** — authentication (15min access + 7d refresh tokens)
- **AES-256-GCM** — encryption for SMTP/SMS credentials

---

## 🛠️ Customisation Guide

### Change branch names
Open `NoorTicketing.html`, find `BRANCHES` array (~line 30):
```javascript
{id:'BR1', code:'BR1', name:'Al Barsha Clinic', city:'Dubai', ...}
//                      ↑ Change this
```

### Add a new user
Find `DEMO_ACCOUNTS` array (~line 20):
```javascript
{
  id:'U8', name:'Your Name', email:'user@noor.ae',
  password:'Password123', role:'End-User',
  branch:'BR1', empId:'EMP-801', av:'YN'
}
```

### Change role permissions
Admin → Master Config → **Access Control** tab — toggle permissions per role visually.

---

## 🔒 Security Notes

- This version uses **in-memory demo data** — no real database
- All data resets on page refresh (by design for demo)
- For production: connect to the backend API (see `/backend` folder)
- Change all default passwords before deploying
- Enable HTTPS — free via Let's Encrypt (see deployment guide)

---

## 📜 License

MIT License — see [LICENSE](./LICENSE) for full text.

Copyright © 2025 Noor Clinic Group

---

## 🤝 Contributing & Support

This is an internal tool for Noor Clinic Group.
For bug reports or feature requests, contact your IT team or the system developer.

Built with ❤️ for better clinic operations across the UAE.
