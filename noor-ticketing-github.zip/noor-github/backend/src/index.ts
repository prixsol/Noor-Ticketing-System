import 'express-async-errors';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { createClient } from 'redis';
import dotenv from 'dotenv';

dotenv.config();

import { testDbConnection } from './config/db';
import { getRedis } from './config/redis';
import { globalErrorHandler } from './shared/errors/AppError';

import { authRouter }     from './modules/auth/auth.routes';
import { ticketsRouter }  from './modules/tickets/tickets.routes';
import { assetsRouter }   from './modules/assets/assets.routes';
import { settingsRouter } from './modules/settings/settings.routes';
import { usersRouter }    from './modules/users/users.routes';
import { branchesRouter } from './modules/branches/branches.routes';
import { auditRouter }    from './modules/audit/audit.routes';

const app = express();

// ─── SECURITY HEADERS ───────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'"],
      styleSrc:   ["'self'", "'unsafe-inline'"],
      imgSrc:     ["'self'", 'data:', 'https:'],
    },
  },
  hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },
}));

// ─── CORS ────────────────────────────────────────────────────
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || '').split(','),
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ─── LOGGING ─────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ─── RATE LIMITING ────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000'),
  max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please slow down.' },
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.LOGIN_RATE_LIMIT_MAX || '5'),
  message: { success: false, error: 'Too many login attempts. Try again in 15 minutes.' },
});

app.use('/api', limiter);
app.use('/api/v1/auth/login', loginLimiter);

// ─── HEALTH CHECK ─────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'branchdesk-api' });
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', version: '1.0.0', timestamp: new Date().toISOString() });
});

// ─── ROUTES ───────────────────────────────────────────────────
app.use('/api/v1/auth',     authRouter);
app.use('/api/v1/tickets',  ticketsRouter);
app.use('/api/v1/assets',   assetsRouter);
app.use('/api/v1/settings', settingsRouter);
app.use('/api/v1/users',    usersRouter);
app.use('/api/v1/branches', branchesRouter);
app.use('/api/v1/audit',    auditRouter);

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'Route not found' });
});

// Global error handler (must be last)
app.use(globalErrorHandler);

// ─── STARTUP ──────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '3000');

async function bootstrap() {
  try {
    await testDbConnection();
    await getRedis();

    app.listen(PORT, () => {
      console.log(`\n✅ BranchDesk API running on port ${PORT}`);
      console.log(`   Environment: ${process.env.NODE_ENV}`);
      console.log(`   Health: http://localhost:${PORT}/health\n`);
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

bootstrap();

export default app;
