import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { stringify } from 'csv-stringify/sync';
import { db } from '../../config/db';
import { authenticate, authorize, branchGuard } from '../../shared/middleware/auth';
import { AppError } from '../../shared/errors/AppError';
import { writeAuditLog } from '../audit/audit.service';

export const assetsRouter = Router();
assetsRouter.use(authenticate);

const AssetSchema = z.object({
  tag:            z.string().min(1).max(50),
  name:           z.string().min(2).max(255),
  assetTypeId:    z.string().uuid(),
  branchId:       z.string().uuid(),
  assignedUserId: z.string().uuid().nullable().optional(),
  serialNumber:   z.string().max(255).optional(),
  purchaseDate:   z.string().optional(),
  warrantyExpiry: z.string().optional(),
  status:         z.enum(['AVAILABLE','ASSIGNED','IN_REPAIR','RETIRED','LOST']).default('AVAILABLE'),
  notes:          z.string().optional(),
  customFields:   z.record(z.any()).optional(),
});

// ─── LIST ───
assetsRouter.get('/', branchGuard, async (req: Request, res: Response) => {
  const { branchId, assetTypeId, status, search, limit = '50', offset = '0' } = req.query as any;
  const { role, branchId: userBranch } = req.user!;

  const params: any[] = [];
  const conditions: string[] = ['a.deleted_at IS NULL'];
  let i = 1;

  if (role === 'Agent' || role === 'EndUser') {
    conditions.push(`a.branch_id = $${i++}`); params.push(userBranch);
  } else if (branchId) {
    conditions.push(`a.branch_id = $${i++}`); params.push(branchId);
  }

  if (assetTypeId) { conditions.push(`a.asset_type_id = $${i++}`); params.push(assetTypeId); }
  if (status)      { conditions.push(`a.status = $${i++}`);       params.push(status); }
  if (search) {
    conditions.push(`(a.name ILIKE $${i} OR a.tag ILIKE $${i} OR a.serial_number ILIKE $${i})`);
    params.push(`%${search}%`); i++;
  }

  const where = `WHERE ${conditions.join(' AND ')}`;

  const [rows, count] = await Promise.all([
    db.query(
      `SELECT a.*, at.name as type_name, b.name as branch_name, u.name as assigned_user_name
       FROM assets a
       LEFT JOIN asset_types at ON a.asset_type_id = at.id
       LEFT JOIN branches b ON a.branch_id = b.id
       LEFT JOIN users u ON a.assigned_user_id = u.id
       ${where}
       ORDER BY a.created_at DESC
       LIMIT $${i} OFFSET $${i+1}`,
      [...params, parseInt(limit), parseInt(offset)]
    ),
    db.query(`SELECT COUNT(*) FROM assets a ${where}`, params),
  ]);

  res.json({ success: true, data: rows.rows, total: parseInt(count.rows[0].count) });
});

// ─── GET ONE ───
assetsRouter.get('/:id', async (req: Request, res: Response) => {
  const result = await db.query(
    `SELECT a.*, at.name as type_name, b.name as branch_name, u.name as assigned_user_name
     FROM assets a
     LEFT JOIN asset_types at ON a.asset_type_id = at.id
     LEFT JOIN branches b ON a.branch_id = b.id
     LEFT JOIN users u ON a.assigned_user_id = u.id
     WHERE a.id = $1 AND a.deleted_at IS NULL`,
    [req.params.id]
  );
  if (!result.rows[0]) throw new AppError('Asset not found', 404);
  res.json({ success: true, data: result.rows[0] });
});

// ─── CREATE ───
assetsRouter.post('/', authorize('Supervisor', 'Admin'), async (req: Request, res: Response) => {
  const body = AssetSchema.parse(req.body);

  // Check tag uniqueness
  const existing = await db.query('SELECT id FROM assets WHERE tag = $1 AND deleted_at IS NULL', [body.tag]);
  if (existing.rows.length) throw new AppError('Asset tag already exists', 409);

  const result = await db.query(
    `INSERT INTO assets (tag, name, asset_type_id, branch_id, assigned_user_id, serial_number,
       purchase_date, warranty_expiry, status, notes, custom_fields)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [body.tag, body.name, body.assetTypeId, body.branchId, body.assignedUserId || null,
     body.serialNumber || null, body.purchaseDate || null, body.warrantyExpiry || null,
     body.status, body.notes || null, body.customFields ? JSON.stringify(body.customFields) : null]
  );

  await writeAuditLog({ actorId: req.user!.id, action: 'CREATE', entityType: 'Asset', entityId: result.rows[0].id });
  res.status(201).json({ success: true, data: result.rows[0] });
});

// ─── UPDATE ───
assetsRouter.patch('/:id', authorize('Supervisor', 'Admin'), async (req: Request, res: Response) => {
  const body = AssetSchema.partial().parse(req.body);

  const existing = await db.query('SELECT * FROM assets WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
  if (!existing.rows[0]) throw new AppError('Asset not found', 404);

  const setClauses: string[] = ['updated_at = NOW()'];
  const params: any[] = [];
  let i = 1;

  const map: Record<string, any> = {
    tag: body.tag, name: body.name, asset_type_id: body.assetTypeId, branch_id: body.branchId,
    assigned_user_id: body.assignedUserId, serial_number: body.serialNumber,
    purchase_date: body.purchaseDate, warranty_expiry: body.warrantyExpiry,
    status: body.status, notes: body.notes,
  };

  for (const [k, v] of Object.entries(map)) {
    if (v !== undefined) { setClauses.push(`${k} = $${i++}`); params.push(v); }
  }

  params.push(req.params.id);
  const updated = await db.query(
    `UPDATE assets SET ${setClauses.join(', ')} WHERE id = $${i} RETURNING *`,
    params
  );

  await writeAuditLog({ actorId: req.user!.id, action: 'UPDATE', entityType: 'Asset', entityId: req.params.id });
  res.json({ success: true, data: updated.rows[0] });
});

// ─── DELETE (soft) ───
assetsRouter.delete('/:id', authorize('Admin'), async (req: Request, res: Response) => {
  const existing = await db.query('SELECT id FROM assets WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
  if (!existing.rows[0]) throw new AppError('Asset not found', 404);

  await db.query("UPDATE assets SET deleted_at = NOW(), status = 'RETIRED' WHERE id = $1", [req.params.id]);
  await writeAuditLog({ actorId: req.user!.id, action: 'DELETE', entityType: 'Asset', entityId: req.params.id });
  res.json({ success: true, message: 'Asset retired and removed' });
});

// ─── EXPORT CSV ───
assetsRouter.get('/export/csv', authorize('Supervisor', 'Admin'), async (req: Request, res: Response) => {
  const result = await db.query(
    `SELECT a.tag, a.name, at.name as type, b.name as branch, a.serial_number,
            a.status, u.name as assigned_to, a.purchase_date, a.warranty_expiry, a.notes
     FROM assets a
     LEFT JOIN asset_types at ON a.asset_type_id = at.id
     LEFT JOIN branches b ON a.branch_id = b.id
     LEFT JOIN users u ON a.assigned_user_id = u.id
     WHERE a.deleted_at IS NULL
     ORDER BY b.name, at.name, a.tag`
  );

  const csv = stringify(result.rows, { header: true, columns: {
    tag: 'Asset Tag', name: 'Name', type: 'Type', branch: 'Branch',
    serial_number: 'Serial', status: 'Status', assigned_to: 'Assigned To',
    purchase_date: 'Purchase Date', warranty_expiry: 'Warranty Expiry', notes: 'Notes'
  }});

  await writeAuditLog({ actorId: req.user!.id, action: 'EXPORT', entityType: 'Asset', entityId: 'bulk' });

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="assets-${new Date().toISOString().slice(0,10)}.csv"`);
  res.send(csv);
});
