import { db } from '../../config/db';

export type AuditAction =
  | 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'LOGOUT'
  | 'ASSIGN' | 'STATUS_CHANGE' | 'SETTINGS_UPDATE' | 'EXPORT';

export interface AuditEntry {
  actorId: string;
  action: AuditAction;
  entityType: string;
  entityId: string;
  diff?: Record<string, { from: any; to: any }>;
  ipAddress?: string;
  userAgent?: string;
}

export async function writeAuditLog(entry: AuditEntry): Promise<void> {
  await db.query(
    `INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, diff, ip_address, user_agent)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [
      entry.actorId,
      entry.action,
      entry.entityType,
      entry.entityId,
      entry.diff ? JSON.stringify(entry.diff) : null,
      entry.ipAddress || null,
      entry.userAgent || null,
    ]
  );
}

export async function getAuditLogs(filters: {
  entityType?: string;
  entityId?: string;
  actorId?: string;
  limit?: number;
  offset?: number;
}) {
  const conditions: string[] = [];
  const params: any[] = [];
  let i = 1;

  if (filters.entityType) { conditions.push(`entity_type = $${i++}`); params.push(filters.entityType); }
  if (filters.entityId) { conditions.push(`entity_id = $${i++}`); params.push(filters.entityId); }
  if (filters.actorId) { conditions.push(`actor_id = $${i++}`); params.push(filters.actorId); }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const limit = filters.limit || 50;
  const offset = filters.offset || 0;

  const result = await db.query(
    `SELECT al.*, u.name as actor_name, u.email as actor_email
     FROM audit_logs al
     LEFT JOIN users u ON al.actor_id = u.id
     ${where}
     ORDER BY al.created_at DESC
     LIMIT $${i} OFFSET $${i + 1}`,
    [...params, limit, offset]
  );
  return result.rows;
}
