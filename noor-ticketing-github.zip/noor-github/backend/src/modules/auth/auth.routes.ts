import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { db } from '../../config/db';
import { AppError } from '../../shared/errors/AppError';
import { authenticate } from '../../shared/middleware/auth';
import { writeAuditLog } from '../audit/audit.service';
import { cacheSet, cacheDel } from '../../config/redis';

export const authRouter = Router();

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

function signTokens(user: { id: string; email: string; role: string; branch_id: string | null; name: string }) {
  const payload = { id: user.id, email: user.email, role: user.role, branchId: user.branch_id, name: user.name };

  const accessToken = jwt.sign(payload, process.env.JWT_SECRET!, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m',
  });

  const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET!, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES || '7d',
  });

  return { accessToken, refreshToken };
}

// POST /api/v1/auth/login
authRouter.post('/login', async (req: Request, res: Response) => {
  const { email, password } = LoginSchema.parse(req.body);

  const result = await db.query(
    `SELECT id, email, name, password_hash, role, branch_id, is_active
     FROM users WHERE email = $1`,
    [email.toLowerCase()]
  );

  const user = result.rows[0];
  if (!user || !user.is_active) throw new AppError('Invalid credentials', 401);

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) throw new AppError('Invalid credentials', 401);

  const { accessToken, refreshToken } = signTokens(user);

  // Store refresh token in Redis (TTL = 7 days)
  await cacheSet(`refresh:${user.id}`, refreshToken, 7 * 24 * 3600);

  // Set refresh token as httpOnly cookie
  res.cookie('refresh_token', refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 7 * 24 * 3600 * 1000,
  });

  await writeAuditLog({
    actorId: user.id,
    action: 'LOGIN',
    entityType: 'User',
    entityId: user.id,
    ipAddress: req.ip,
    userAgent: req.headers['user-agent'],
  });

  res.json({
    success: true,
    data: {
      user: { id: user.id, email: user.email, name: user.name, role: user.role, branchId: user.branch_id },
      accessToken,
    },
  });
});

// POST /api/v1/auth/refresh
authRouter.post('/refresh', async (req: Request, res: Response) => {
  const token = req.cookies?.refresh_token;
  if (!token) throw new AppError('Refresh token missing', 401);

  let payload: any;
  try {
    payload = jwt.verify(token, process.env.JWT_REFRESH_SECRET!);
  } catch {
    throw new AppError('Invalid or expired refresh token', 401);
  }

  const stored = await cacheSet(`refresh:${payload.id}`, '', 0); // check existence
  const userResult = await db.query('SELECT * FROM users WHERE id = $1 AND is_active = true', [payload.id]);
  const user = userResult.rows[0];
  if (!user) throw new AppError('User not found', 401);

  const { accessToken, refreshToken: newRefresh } = signTokens(user);
  await cacheSet(`refresh:${user.id}`, newRefresh, 7 * 24 * 3600);

  res.cookie('refresh_token', newRefresh, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 7 * 24 * 3600 * 1000,
  });

  res.json({ success: true, data: { accessToken } });
});

// POST /api/v1/auth/logout
authRouter.post('/logout', authenticate, async (req: Request, res: Response) => {
  await cacheDel(`refresh:${req.user!.id}`);
  res.clearCookie('refresh_token');
  await writeAuditLog({ actorId: req.user!.id, action: 'LOGOUT', entityType: 'User', entityId: req.user!.id });
  res.json({ success: true, message: 'Logged out successfully' });
});

// GET /api/v1/auth/me
authRouter.get('/me', authenticate, async (req: Request, res: Response) => {
  const result = await db.query(
    'SELECT id, email, name, role, branch_id, created_at FROM users WHERE id = $1',
    [req.user!.id]
  );
  res.json({ success: true, data: result.rows[0] });
});
