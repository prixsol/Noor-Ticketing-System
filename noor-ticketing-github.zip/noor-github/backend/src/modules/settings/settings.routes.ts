import { Router, Request, Response } from 'express';
import { z } from 'zod';
import nodemailer from 'nodemailer';
import { db } from '../../config/db';
import { authenticate, authorize } from '../../shared/middleware/auth';
import { encrypt, decrypt, mask } from '../../config/encryption';
import { AppError } from '../../shared/errors/AppError';
import { writeAuditLog } from '../audit/audit.service';

export const settingsRouter = Router();
settingsRouter.use(authenticate, authorize('Admin'));

const SENSITIVE_KEYS = ['smtp_password', 'sms_password', 'sms_api_key'];

async function getSetting(key: string): Promise<string | null> {
  const result = await db.query('SELECT value, is_encrypted FROM settings WHERE key = $1', [key]);
  if (!result.rows[0]) return null;
  const { value, is_encrypted } = result.rows[0];
  return is_encrypted ? decrypt(value) : value;
}

async function setSetting(key: string, value: string, updatedBy: string): Promise<void> {
  const isSensitive = SENSITIVE_KEYS.includes(key);
  const storedValue = isSensitive ? encrypt(value) : value;

  await db.query(
    `INSERT INTO settings (key, value, is_encrypted, updated_by, updated_at)
     VALUES ($1, $2, $3, $4, NOW())
     ON CONFLICT (key) DO UPDATE SET value = $2, is_encrypted = $3, updated_by = $4, updated_at = NOW()`,
    [key, storedValue, isSensitive, updatedBy]
  );
}

// ─── GET SMTP ───
settingsRouter.get('/smtp', async (req: Request, res: Response) => {
  const keys = ['smtp_host','smtp_port','smtp_tls','smtp_username','smtp_password','smtp_sender_email','smtp_sender_name'];
  const result: Record<string, any> = {};

  for (const key of keys) {
    const val = await getSetting(key);
    // Mask sensitive values before sending to client
    result[key.replace('smtp_', '')] = SENSITIVE_KEYS.includes(key) ? mask(val || '') : val;
  }

  res.json({ success: true, data: result });
});

// ─── SAVE SMTP ───
settingsRouter.post('/smtp', async (req: Request, res: Response) => {
  const SmtpSchema = z.object({
    host:        z.string().min(1),
    port:        z.number().int().min(1).max(65535),
    tls:         z.boolean(),
    username:    z.string().min(1),
    password:    z.string().optional(),  // optional — don't overwrite if not provided
    senderEmail: z.string().email(),
    senderName:  z.string().min(1),
  });

  const body = SmtpSchema.parse(req.body);

  await setSetting('smtp_host',         body.host,        req.user!.id);
  await setSetting('smtp_port',         String(body.port), req.user!.id);
  await setSetting('smtp_tls',          String(body.tls),  req.user!.id);
  await setSetting('smtp_username',     body.username,     req.user!.id);
  await setSetting('smtp_sender_email', body.senderEmail,  req.user!.id);
  await setSetting('smtp_sender_name',  body.senderName,   req.user!.id);

  if (body.password && !body.password.includes('•')) {
    await setSetting('smtp_password', body.password, req.user!.id);
  }

  await writeAuditLog({ actorId: req.user!.id, action: 'SETTINGS_UPDATE', entityType: 'Settings', entityId: 'smtp' });
  res.json({ success: true, message: 'SMTP settings saved and encrypted' });
});

// ─── TEST SMTP ───
settingsRouter.post('/smtp/test', async (req: Request, res: Response) => {
  const { to } = z.object({ to: z.string().email() }).parse(req.body);

  const [host, port, tls, user, password, senderEmail, senderName] = await Promise.all([
    getSetting('smtp_host'), getSetting('smtp_port'), getSetting('smtp_tls'),
    getSetting('smtp_username'), getSetting('smtp_password'),
    getSetting('smtp_sender_email'), getSetting('smtp_sender_name'),
  ]);

  if (!host || !port || !user || !password) throw new AppError('SMTP not fully configured', 422);

  const transporter = nodemailer.createTransporter({
    host, port: parseInt(port!),
    secure: tls === 'true',
    auth: { user, pass: password },
  });

  try {
    await transporter.verify();
    await transporter.sendMail({
      from: `"${senderName}" <${senderEmail}>`,
      to,
      subject: 'BranchDesk — SMTP Test Email',
      text: 'This is a test email from BranchDesk. Your SMTP configuration is working correctly.',
    });
    res.json({ success: true, message: `Test email sent successfully to ${to}` });
  } catch (err: any) {
    throw new AppError(`SMTP test failed: ${err.message}`, 502);
  }
});

// ─── GET SMS ───
settingsRouter.get('/sms', async (req: Request, res: Response) => {
  const keys = ['sms_provider_url','sms_username','sms_password','sms_api_key','sms_sender_id'];
  const result: Record<string, any> = {};

  for (const key of keys) {
    const val = await getSetting(key);
    result[key.replace('sms_', '')] = SENSITIVE_KEYS.includes(key) ? mask(val || '') : val;
  }

  res.json({ success: true, data: result });
});

// ─── SAVE SMS ───
settingsRouter.post('/sms', async (req: Request, res: Response) => {
  const SmsSchema = z.object({
    providerUrl: z.string().url(),
    username:    z.string().min(1),
    password:    z.string().optional(),
    apiKey:      z.string().optional(),
    senderId:    z.string().min(1).max(11),
  });

  const body = SmsSchema.parse(req.body);

  await setSetting('sms_provider_url', body.providerUrl, req.user!.id);
  await setSetting('sms_username',     body.username,    req.user!.id);
  await setSetting('sms_sender_id',    body.senderId,    req.user!.id);

  if (body.password && !body.password.includes('•')) {
    await setSetting('sms_password', body.password, req.user!.id);
  }
  if (body.apiKey && !body.apiKey.includes('•')) {
    await setSetting('sms_api_key', body.apiKey, req.user!.id);
  }

  await writeAuditLog({ actorId: req.user!.id, action: 'SETTINGS_UPDATE', entityType: 'Settings', entityId: 'sms' });
  res.json({ success: true, message: 'SMS settings saved and encrypted' });
});

// ─── TEST SMS ───
settingsRouter.post('/sms/test', async (req: Request, res: Response) => {
  const { to } = z.object({ to: z.string().min(8) }).parse(req.body);

  const [url, username, password, apiKey, senderId] = await Promise.all([
    getSetting('sms_provider_url'), getSetting('sms_username'),
    getSetting('sms_password'), getSetting('sms_api_key'), getSetting('sms_sender_id'),
  ]);

  if (!url || !username) throw new AppError('SMS not fully configured', 422);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
      },
      body: JSON.stringify({ to, from: senderId, body: 'BranchDesk test SMS — configuration is working.', username, password }),
    });

    if (!response.ok) throw new Error(`Provider returned ${response.status}`);
    res.json({ success: true, message: `Test SMS sent to ${to}` });
  } catch (err: any) {
    throw new AppError(`SMS test failed: ${err.message}`, 502);
  }
});
