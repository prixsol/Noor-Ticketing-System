import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { db } from '../../config/db';
import { authenticate, authorize, branchGuard } from '../../shared/middleware/auth';
import { AppError } from '../../shared/errors/AppError';
import { writeAuditLog } from '../audit/audit.service';
import { cacheDelPattern } from '../../config/redis';

export const ticketsRouter = Router();
ticketsRouter.use(authenticate);

const SLA_HOURS: Record<string, number> = { P1: 4, P2: 8, P3: 48, P4: 120 };

const CreateTicketSchema = z.object({
  branchId:    z.string().uuid(),
  title:       z.string().min(5).max(255),
  description: z.string().min(10),
  priority:    z.enum(['P1', 'P2', 'P3', 'P4']).default('P3'),
  categoryId:  z.string().uuid().optional(),
  assignedTo:  z.string().uuid().optional(),
});

const UpdateTicketSchema = z.object({
  title:       z.string().min(5).max(255).optional(),
  description: z.string().min(10).optional(),
  priority:    z.enum(['P1', 'P2', 'P3', 'P4']).optional(),
  status:      z.enum(['NEW','ASSIGNED','IN_PROGRESS','PENDING_CUSTOMER','ESCALATED','RESOLVED','CLOSED','CANCELLED']).optional(),
  assignedTo:  z.string().uuid().nullable().optional(),
  categoryId:  z.string().uuid().optional(),
});

const CommentSchema = z.object({
  body:       z.string().min(1),
  isInternal: z.boolean().default(false),
});

// ─── LIST ───
ticketsRouter.get('/', branchGuard, async (req: Request, res: Response) => {
  const { status, priority, branchId, assignedTo, search, limit = '25', offset = '0' } = req.query as any;
  const { role, branchId: userBranch } = req.user!;

  const params: any[] = [];
  const conditions: string[] = ['t.deleted_at IS NULL'];
  let i = 1;

  // Branch scoping
  if (role === 'Agent' || role === 'EndUser') {
    conditions.push(`t.branch_id = $${i++}`); params.push(userBranch);
  } else if (branchId) {
    conditions.push(`t.branch_id = $${i++}`); params.push(branchId);
  }

  if (status)     { conditions.push(`t.status = $${i++}`);      params.push(status); }
  if (priority)   { conditions.push(`t.priority = $${i++}`);    params.push(priority); }
  if (assignedTo) { conditions.push(`t.assigned_to = $${i++}`); params.push(assignedTo); }
  if (search)     {
    conditions.push(`(t.title ILIKE $${i} OR t.ticket_number ILIKE $${i})`);
    params.push(`%${search}%`); i++;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const [rows, count] = await Promise.all([
    db.query(
      `SELECT t.*, b.name as branch_name,
              ub.name as created_by_name, ua.name as assigned_to_name,
              c.name as category_name,
              (SELECT COUNT(*) FROM ticket_comments tc WHERE tc.ticket_id = t.id) as comment_count
       FROM tickets t
       LEFT JOIN branches b ON t.branch_id = b.id
       LEFT JOIN users ub ON t.created_by = ub.id
       LEFT JOIN users ua ON t.assigned_to = ua.id
       LEFT JOIN ticket_categories c ON t.category_id = c.id
       ${where}
       ORDER BY
         CASE t.priority WHEN 'P1' THEN 1 WHEN 'P2' THEN 2 WHEN 'P3' THEN 3 ELSE 4 END,
         t.created_at DESC
       LIMIT $${i} OFFSET $${i+1}`,
      [...params, parseInt(limit), parseInt(offset)]
    ),
    db.query(`SELECT COUNT(*) FROM tickets t ${where}`, params),
  ]);

  res.json({ success: true, data: rows.rows, total: parseInt(count.rows[0].count), limit: parseInt(limit), offset: parseInt(offset) });
});

// ─── GET ONE ───
ticketsRouter.get('/:id', async (req: Request, res: Response) => {
  const result = await db.query(
    `SELECT t.*, b.name as branch_name,
            ub.name as created_by_name, ua.name as assigned_to_name,
            c.name as category_name
     FROM tickets t
     LEFT JOIN branches b ON t.branch_id = b.id
     LEFT JOIN users ub ON t.created_by = ub.id
     LEFT JOIN users ua ON t.assigned_to = ua.id
     LEFT JOIN ticket_categories c ON t.category_id = c.id
     WHERE t.id = $1 AND t.deleted_at IS NULL`,
    [req.params.id]
  );

  const ticket = result.rows[0];
  if (!ticket) throw new AppError('Ticket not found', 404);

  // Branch guard for non-admins
  const { role, branchId } = req.user!;
  if ((role === 'Agent' || role === 'EndUser') && ticket.branch_id !== branchId) {
    throw new AppError('Access denied', 403);
  }

  const [comments, history] = await Promise.all([
    db.query(
      `SELECT tc.*, u.name as author_name, u.role as author_role
       FROM ticket_comments tc
       LEFT JOIN users u ON tc.user_id = u.id
       WHERE tc.ticket_id = $1
       ORDER BY tc.created_at ASC`,
      [ticket.id]
    ),
    db.query(
      `SELECT tsh.*, u.name as changed_by_name
       FROM ticket_status_history tsh
       LEFT JOIN users u ON tsh.changed_by = u.id
       WHERE tsh.ticket_id = $1
       ORDER BY tsh.changed_at ASC`,
      [ticket.id]
    ),
  ]);

  ticket.comments = comments.rows;
  ticket.history = history.rows;

  res.json({ success: true, data: ticket });
});

// ─── CREATE ───
ticketsRouter.post('/', async (req: Request, res: Response) => {
  const body = CreateTicketSchema.parse(req.body);
  const { id: userId, role, branchId: userBranch } = req.user!;

  // EndUsers can only create for their own branch
  if ((role === 'Agent' || role === 'EndUser') && body.branchId !== userBranch) {
    throw new AppError('Cannot create ticket for another branch', 403);
  }

  const slaHours = SLA_HOURS[body.priority];
  const slaBreachAt = new Date(Date.now() + slaHours * 3600000);

  const result = await db.transaction(async (client) => {
    const ticket = await client.query(
      `INSERT INTO tickets (branch_id, created_by, assigned_to, title, description, priority, category_id, status, sla_breach_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [body.branchId, userId, body.assignedTo || null, body.title, body.description, body.priority, body.categoryId || null,
       body.assignedTo ? 'ASSIGNED' : 'NEW', slaBreachAt]
    );

    if (body.assignedTo) {
      await client.query(
        `INSERT INTO ticket_status_history (ticket_id, from_status, to_status, changed_by) VALUES ($1, $2, $3, $4)`,
        [ticket.rows[0].id, 'NEW', 'ASSIGNED', userId]
      );
    }

    return ticket.rows[0];
  });

  await writeAuditLog({ actorId: userId, action: 'CREATE', entityType: 'Ticket', entityId: result.id });
  await cacheDelPattern('dashboard:*');

  res.status(201).json({ success: true, data: result });
});

// ─── UPDATE ───
ticketsRouter.patch('/:id', async (req: Request, res: Response) => {
  const body = UpdateTicketSchema.parse(req.body);
  const { id: userId, role, branchId: userBranch } = req.user!;

  const existing = await db.query('SELECT * FROM tickets WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
  const ticket = existing.rows[0];
  if (!ticket) throw new AppError('Ticket not found', 404);

  if ((role === 'Agent' || role === 'EndUser') && ticket.branch_id !== userBranch) {
    throw new AppError('Access denied', 403);
  }

  const diff: Record<string, any> = {};
  const setClauses: string[] = ['updated_at = NOW()'];
  const params: any[] = [];
  let i = 1;

  const fields: Record<string, any> = {
    title: body.title, description: body.description, priority: body.priority,
    assigned_to: body.assignedTo, category_id: body.categoryId,
  };

  for (const [key, val] of Object.entries(fields)) {
    if (val !== undefined) {
      setClauses.push(`${key} = $${i++}`);
      params.push(val);
      diff[key] = { from: ticket[key], to: val };
    }
  }

  // Status change with history tracking
  if (body.status && body.status !== ticket.status) {
    setClauses.push(`status = $${i++}`);
    params.push(body.status);
    diff['status'] = { from: ticket.status, to: body.status };

    if (body.status === 'RESOLVED' || body.status === 'CLOSED') {
      setClauses.push(`resolved_at = NOW()`);
    }
  }

  params.push(req.params.id);

  await db.transaction(async (client) => {
    await client.query(`UPDATE tickets SET ${setClauses.join(', ')} WHERE id = $${i}`, params);

    if (body.status && body.status !== ticket.status) {
      await client.query(
        `INSERT INTO ticket_status_history (ticket_id, from_status, to_status, changed_by) VALUES ($1, $2, $3, $4)`,
        [req.params.id, ticket.status, body.status, userId]
      );
    }
  });

  await writeAuditLog({ actorId: userId, action: 'UPDATE', entityType: 'Ticket', entityId: req.params.id, diff });
  await cacheDelPattern('dashboard:*');

  const updated = await db.query('SELECT * FROM tickets WHERE id = $1', [req.params.id]);
  res.json({ success: true, data: updated.rows[0] });
});

// ─── ADD COMMENT ───
ticketsRouter.post('/:id/comments', async (req: Request, res: Response) => {
  const body = CommentSchema.parse(req.body);
  const { id: userId, role } = req.user!;

  const ticket = await db.query('SELECT * FROM tickets WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
  if (!ticket.rows[0]) throw new AppError('Ticket not found', 404);

  // EndUsers cannot post internal notes
  if (body.isInternal && role === 'EndUser') throw new AppError('End users cannot post internal notes', 403);

  const result = await db.query(
    `INSERT INTO ticket_comments (ticket_id, user_id, body, is_internal)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [req.params.id, userId, body.body, body.isInternal]
  );

  // Update ticket's updated_at
  await db.query('UPDATE tickets SET updated_at = NOW() WHERE id = $1', [req.params.id]);

  res.status(201).json({ success: true, data: result.rows[0] });
});

// ─── DELETE (soft) ───
ticketsRouter.delete('/:id', authorize('Admin', 'Supervisor'), async (req: Request, res: Response) => {
  await db.query('UPDATE tickets SET deleted_at = NOW(), status = $1 WHERE id = $2', ['CANCELLED', req.params.id]);
  await writeAuditLog({ actorId: req.user!.id, action: 'DELETE', entityType: 'Ticket', entityId: req.params.id });
  res.json({ success: true, message: 'Ticket cancelled' });
});
