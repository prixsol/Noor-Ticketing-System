import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { AppError } from '../errors/AppError';

export type UserRole = 'Admin' | 'Supervisor' | 'Agent' | 'EndUser';

export interface AuthUser {
  id: string;
  email: string;
  role: UserRole;
  branchId: string | null;
  name: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

/** Verifies JWT and attaches user to req.user */
export function authenticate(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith('Bearer ')) throw new AppError('Authentication required', 401);

  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as AuthUser & { iat: number; exp: number };
    req.user = { id: payload.id, email: payload.email, role: payload.role, branchId: payload.branchId, name: payload.name };
    next();
  } catch (err) {
    throw new AppError('Invalid or expired token', 401);
  }
}

/** Role-based access control */
export function authorize(...roles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) throw new AppError('Authentication required', 401);
    if (!roles.includes(req.user.role)) {
      throw new AppError(`Access denied. Required role: ${roles.join(' or ')}`, 403);
    }
    next();
  };
}

/** Ensures user can only access their own branch data (unless Admin/Supervisor) */
export function branchGuard(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) throw new AppError('Authentication required', 401);

  const { role, branchId } = req.user;
  const requestedBranch = req.params.branchId || req.query.branchId || req.body.branchId;

  // Admin sees all
  if (role === 'Admin') return next();

  // Supervisor sees all (read) but can only mutate own branch
  if (role === 'Supervisor') return next();

  // Agent and EndUser can only access their own branch
  if (requestedBranch && requestedBranch !== branchId) {
    throw new AppError('Access denied: cross-branch access not permitted', 403);
  }
  next();
}

const ROLE_HIERARCHY: Record<UserRole, number> = {
  EndUser: 0,
  Agent: 1,
  Supervisor: 2,
  Admin: 3,
};

export function hasRole(userRole: UserRole, requiredRole: UserRole): boolean {
  return ROLE_HIERARCHY[userRole] >= ROLE_HIERARCHY[requiredRole];
}
