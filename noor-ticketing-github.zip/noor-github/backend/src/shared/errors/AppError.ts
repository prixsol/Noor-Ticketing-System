import { Request, Response, NextFunction } from 'express';

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;

  constructor(message: string, statusCode = 500, isOperational = true) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export function globalErrorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  console.error(`[ERROR] ${req.method} ${req.path}:`, err.message);
  if (process.env.NODE_ENV === 'development') console.error(err.stack);

  // Known operational errors
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      success: false,
      error: err.message,
    });
  }

  // PostgreSQL unique violation
  if ((err as any).code === '23505') {
    return res.status(409).json({ success: false, error: 'Duplicate entry — record already exists' });
  }

  // PostgreSQL foreign key violation
  if ((err as any).code === '23503') {
    return res.status(400).json({ success: false, error: 'Referenced record not found' });
  }

  // Zod validation errors
  if (err.name === 'ZodError') {
    return res.status(422).json({ success: false, error: 'Validation failed', details: (err as any).errors });
  }

  // JWT errors handled in middleware
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({ success: false, error: 'Invalid token' });
  }

  // Unhandled — generic 500
  return res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
}
