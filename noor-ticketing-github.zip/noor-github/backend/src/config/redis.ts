import { createClient } from 'redis';

let redisClient: ReturnType<typeof createClient>;

export async function getRedis() {
  if (!redisClient) {
    redisClient = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
    redisClient.on('error', (err) => console.error('Redis error:', err));
    await redisClient.connect();
    console.log('✅ Redis connected');
  }
  return redisClient;
}

export async function cacheGet<T>(key: string): Promise<T | null> {
  const client = await getRedis();
  const val = await client.get(key);
  return val ? JSON.parse(val) : null;
}

export async function cacheSet(key: string, value: any, ttlSeconds = 60): Promise<void> {
  const client = await getRedis();
  await client.setEx(key, ttlSeconds, JSON.stringify(value));
}

export async function cacheDel(key: string): Promise<void> {
  const client = await getRedis();
  await client.del(key);
}

export async function cacheDelPattern(pattern: string): Promise<void> {
  const client = await getRedis();
  const keys = await client.keys(pattern);
  if (keys.length > 0) await client.del(keys);
}
