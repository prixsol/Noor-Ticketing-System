-- BranchDesk Complete Database Schema
-- Run with: node-pg-migrate up
-- Or manually: psql -U branchdesk -d branchdesk -f migrations/001_initial_schema.sql

-- ─── EXTENSIONS ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";   -- for full-text search

-- ─── BRANCHES ────────────────────────────────────────────────
CREATE TABLE branches (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code          VARCHAR(10)  UNIQUE NOT NULL,
  name          VARCHAR(255) NOT NULL,
  city          VARCHAR(100),
  address       TEXT,
  contact_email VARCHAR(255),
  contact_phone VARCHAR(50),
  manager_name  VARCHAR(255),
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── USERS ───────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('Admin', 'Supervisor', 'Agent', 'EndUser');

CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  branch_id      UUID REFERENCES branches(id) ON DELETE SET NULL,
  name           VARCHAR(255) NOT NULL,
  email          VARCHAR(255) UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,
  role           user_role NOT NULL DEFAULT 'Agent',
  is_active      BOOLEAN NOT NULL DEFAULT true,
  last_login_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email     ON users(email);
CREATE INDEX idx_users_branch_id ON users(branch_id);
CREATE INDEX idx_users_role      ON users(role);

-- ─── TICKET CATEGORIES ───────────────────────────────────────
CREATE TABLE ticket_categories (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       VARCHAR(255) UNIQUE NOT NULL,
  is_active  BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── TICKETS ─────────────────────────────────────────────────
CREATE TYPE ticket_status AS ENUM (
  'NEW', 'ASSIGNED', 'IN_PROGRESS', 'PENDING_CUSTOMER',
  'ESCALATED', 'RESOLVED', 'CLOSED', 'REOPENED', 'CANCELLED'
);
CREATE TYPE ticket_priority AS ENUM ('P1', 'P2', 'P3', 'P4');

CREATE SEQUENCE ticket_seq START 1000;

CREATE TABLE tickets (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_number  VARCHAR(20) UNIQUE NOT NULL DEFAULT 'TKT-' || nextval('ticket_seq'),
  branch_id      UUID NOT NULL REFERENCES branches(id),
  created_by     UUID NOT NULL REFERENCES users(id),
  assigned_to    UUID REFERENCES users(id),
  category_id    UUID REFERENCES ticket_categories(id),
  title          VARCHAR(255) NOT NULL,
  description    TEXT NOT NULL,
  status         ticket_status NOT NULL DEFAULT 'NEW',
  priority       ticket_priority NOT NULL DEFAULT 'P3',
  sla_breach_at  TIMESTAMPTZ,
  resolved_at    TIMESTAMPTZ,
  deleted_at     TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Performance indexes
CREATE INDEX idx_tickets_branch_id    ON tickets(branch_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_assigned_to  ON tickets(assigned_to) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_status       ON tickets(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_priority     ON tickets(priority) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_created_at   ON tickets(created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_sla          ON tickets(sla_breach_at) WHERE status NOT IN ('CLOSED','CANCELLED') AND deleted_at IS NULL;
CREATE INDEX idx_tickets_search       ON tickets USING gin(to_tsvector('english', title || ' ' || description));

-- ─── TICKET COMMENTS ─────────────────────────────────────────
CREATE TABLE ticket_comments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id   UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id),
  body        TEXT NOT NULL,
  is_internal BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_comments_ticket_id ON ticket_comments(ticket_id);

-- ─── TICKET STATUS HISTORY ───────────────────────────────────
CREATE TABLE ticket_status_history (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id    UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  from_status  ticket_status,
  to_status    ticket_status NOT NULL,
  changed_by   UUID NOT NULL REFERENCES users(id),
  changed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tsh_ticket_id ON ticket_status_history(ticket_id);

-- ─── TICKET ATTACHMENTS ──────────────────────────────────────
CREATE TABLE ticket_attachments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id   UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  uploaded_by UUID NOT NULL REFERENCES users(id),
  file_key    VARCHAR(500) NOT NULL,
  file_name   VARCHAR(255) NOT NULL,
  file_size   INTEGER,
  mime_type   VARCHAR(100),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── ASSET TYPES ─────────────────────────────────────────────
CREATE TABLE asset_types (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       VARCHAR(255) UNIQUE NOT NULL,
  icon_key   VARCHAR(50) DEFAULT 'Package',
  is_active  BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── ASSETS ──────────────────────────────────────────────────
CREATE TYPE asset_status AS ENUM ('AVAILABLE', 'ASSIGNED', 'IN_REPAIR', 'RETIRED', 'LOST');

CREATE TABLE assets (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tag              VARCHAR(50) UNIQUE NOT NULL,
  name             VARCHAR(255) NOT NULL,
  asset_type_id    UUID NOT NULL REFERENCES asset_types(id),
  branch_id        UUID NOT NULL REFERENCES branches(id),
  assigned_user_id UUID REFERENCES users(id),
  serial_number    VARCHAR(255),
  purchase_date    DATE,
  warranty_expiry  DATE,
  status           asset_status NOT NULL DEFAULT 'AVAILABLE',
  notes            TEXT,
  custom_fields    JSONB DEFAULT '{}',
  deleted_at       TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_assets_branch_id  ON assets(branch_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_type_id    ON assets(asset_type_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_status     ON assets(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_tag        ON assets(tag) WHERE deleted_at IS NULL;
CREATE INDEX idx_assets_custom     ON assets USING gin(custom_fields);

-- ─── SETTINGS ────────────────────────────────────────────────
CREATE TABLE settings (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key          VARCHAR(100) UNIQUE NOT NULL,
  value        TEXT,
  is_encrypted BOOLEAN NOT NULL DEFAULT false,
  updated_by   UUID REFERENCES users(id),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MASTER CONFIG ───────────────────────────────────────────
CREATE TABLE master_config (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  config_key   VARCHAR(100) UNIQUE NOT NULL,
  config_value JSONB NOT NULL DEFAULT '{}',
  description  TEXT,
  updated_by   UUID REFERENCES users(id),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── NOTIFICATIONS ───────────────────────────────────────────
CREATE TYPE notification_channel AS ENUM ('email', 'sms', 'in_app');
CREATE TYPE notification_status  AS ENUM ('pending', 'sent', 'failed');

CREATE TABLE notifications (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id),
  ticket_id  UUID REFERENCES tickets(id),
  channel    notification_channel NOT NULL,
  subject    VARCHAR(500),
  body       TEXT,
  status     notification_status NOT NULL DEFAULT 'pending',
  sent_at    TIMESTAMPTZ,
  error_msg  TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_status  ON notifications(status);

-- ─── AUDIT LOGS ──────────────────────────────────────────────
CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  actor_id    UUID REFERENCES users(id),
  action      VARCHAR(50) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id   VARCHAR(255) NOT NULL,
  diff        JSONB,
  ip_address  INET,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_actor      ON audit_logs(actor_id);
CREATE INDEX idx_audit_logs_entity     ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);

-- ─── SEED DATA ───────────────────────────────────────────────
INSERT INTO branches (code, name, city, manager_name) VALUES
  ('BR1', 'Al Barsha Clinic',  'Dubai',     'Ahmed Al-Farsi'),
  ('BR2', 'Deira Medical',     'Dubai',     'Sara Hassan'),
  ('BR3', 'Jumeirah Health',   'Dubai',     'Mohammed Khalid'),
  ('BR4', 'Bur Dubai Centre',  'Dubai',     'Fatima Al-Ali'),
  ('BR5', 'Sharjah Clinic',    'Sharjah',   'Omar Abdullah'),
  ('BR6', 'Abu Dhabi North',   'Abu Dhabi', 'Layla Saeed'),
  ('BR7', 'Ajman Branch',      'Ajman',     'Khalid Nasser'),
  ('BR8', 'Al Ain Clinic',     'Al Ain',    'Hessa Mohammed');

INSERT INTO asset_types (name, icon_key, sort_order) VALUES
  ('PC / Desktop',      'Monitor',    1),
  ('Laptop',            'Laptop',     2),
  ('Keyboard',          'Keyboard',   3),
  ('Mouse',             'Mouse',      4),
  ('HID Reader',        'Cpu',        5),
  ('Charger',           'Zap',        6),
  ('Scanner',           'Layers',     7),
  ('Printer',           'Printer',    8),
  ('Software License',  'Key',        9),
  ('Phone',             'Smartphone', 10),
  ('SIM Card',          'Hash',       11),
  ('Monitor / Display', 'Monitor',    12),
  ('UPS / Battery',     'Database',   13),
  ('Network Switch',    'Globe',      14);

INSERT INTO ticket_categories (name) VALUES
  ('Hardware Failure'),
  ('Software Issue'),
  ('Network Problem'),
  ('Access Request'),
  ('Printer Issue'),
  ('Email Problem'),
  ('New Setup'),
  ('Maintenance'),
  ('Other');

-- Default admin user (password: Admin@1234 — CHANGE IMMEDIATELY)
-- Hash generated with: bcrypt.hashSync('Admin@1234', 12)
INSERT INTO users (name, email, password_hash, role, branch_id) VALUES
  ('System Admin', 'admin@branchdesk.local',
   '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQyCkMJeJOJbf.UNlhKFDrfbq',
   'Admin', NULL);
